<?php
/**
* file: settings.inc.php
* Settings for game database on CWP
* Initial program 9/7/18
* Updated program 9/15/18 -- changed to mysqli
*/

// Variables used for database access
$hostname_wbgpoker = "localhost";
$database_wbgpoker = "rbocarmy_wbgpoker";
$username_wbgpoker = "rbocarmy_wbg450";
$password_wbgpoker = "D3vryUn1v3rs1ty";

//Set up access to the online database using PHP mysqli functions
$link = mysqli_connect($hostname_wbgpoker,$username_wbgpoker,$password_wbgpoker,$database_wbgpoker);
if (!$link) {
	die('Could not connect to MySQL: ' . mysqli_error($link));
}
//echo 'Connection OK';


?>