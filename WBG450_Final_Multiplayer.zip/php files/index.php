<?php
//New PHP index file
?>
<html>
	<body>
		<?php phpinfo(); ?>
	</body>
</html>
