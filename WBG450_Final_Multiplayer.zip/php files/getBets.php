<?php
	
//=================================================================================
// YOUR BUSINESS NAME
// PROJECT TITLE:		WBGPOKER GAME
// PROJECT DATE:		01/01/20xx
// PROGRAMMER: 			you
// FILE NAME:			getBets.php
// DESCRIPTION:			Returns info to both server and clients on given game
// LAST UPDATE:			01/01/20xx
//=================================================================================

require_once("settings.inc.php");

//=================================================================================
// GLOBALS & CONSTANTS
//=================================================================================
$numPlayers = 0;
$round = 0;	
$numBets = 0;


//=================================================================================
// INCOMING VARIABLES
//=================================================================================

$g_id = $_POST['g_id'];
if(!isset($g_id)){
	$g_id = $_GET['g_id'];
} // end if
	
//=================================================================================
// SUPPORTING FUNCTIONS
//=================================================================================
	
function gameOver($link,$gameID){
	// Get current round from game
	$query = "SELECT * FROM `game` WHERE `g_id`=$gameID AND `g_gameOver` IS NULL";	
	$result = @mysqli_query($link, $query);
	if(mysqli_error($link)) handleError("query 1");
	
	if(mysqli_num_rows($result)==0){
		return true;
	}else{
		return false;
	} // end if-else
		
} // end function

function gameIsOver($link,$gameID){
    $query = "UPDATE `game` SET `g_gameOver` = now() WHERE `g_id`=$gameID";
    $result = @mysqli_query($link, $query);
    if(mysqli_error($link)) handleError("query 1a");
}
			
function getCurrentRound($link,$gameID){
	// Get current round from game
	$query = "SELECT `g_currentRound` FROM `game` WHERE `g_id`=$gameID";	
	$result = @mysqli_query($link, $query);
	if(mysqli_error($link)) handleError("query 2");	
	$row = mysqli_fetch_row($result);
	return $row[0];
	
} // end function
	
function getNumPlayers($link,$gameID){
	$query = "SELECT count(`gpl_id`) FROM `game_player` WHERE `g_id` = $gameID";
	$result = @mysqli_query($link, $query);
	if(mysqli_error($link)) handleError("query 3");
	$row = mysqli_fetch_row($result);
	return $row[0];
	
} // end function
	
function getNumBetsForRound($link,$gameID,$round){
	$query = "SELECT * FROM `bet` WHERE `g_id`=$gameID AND `b_round`= $round";	
	$result = @mysqli_query($link, $query);
	if(mysqli_error($link)) handleError("query 4");
	return mysqli_num_rows($result);
} //end function
	
function updateRound($link,$gameID){
    $query = "UPDATE `game` SET `g_currentRound` = `g_currentRound` + 1 WHERE `g_id` = $gameID";
    $result = mysqli_query($link,$query);
    if(mysqli_error($link)) handleError("query 5"); 
}//end function 
	

    
function getAllBets($link,$gameID){
     $data = "";
     $query = "SELECT `b_round`,`b_id`,`p_id`,`b_amt` FROM `bet` WHERE `g_id`=$gameID ORDER BY `b_round`, `b_id` ASC";
     $result = @mysqli_query($link, $query);
     if(mysqli_error($link)) handleError("query 6");
     $N = mysqli_num_rows($result);
     
     
     for($i=0;$i<$N;$i++){
         $row = mysqli_fetch_assoc($result);
         if($i < $N-1)  {
           $data .=  $row['b_round'] . "|" . $row['b_id'] . "|" . $row['p_id'] . "|" . $row['b_amt'] . "^";
         }else{
            $data .=  $row['b_round'] . "|" . $row['b_id'] . "|" . $row['p_id'] . "|" . $row['b_amt'];
         } // end if          
     }//end for
     
      return $data;  
     
} //end function

function getTotalPot($link,$gameID){
    $query = "SELECT sum(`b_amt`) FROM `bet` WHERE `g_id` = $gameID";
    $result = @mysqli_query($link, $query);
    if(mysqli_error($link)) handleError("query 7"); 
    $row = mysqli_fetch_row($result);
    return $row[0];
}  //end function

function updateGame($link,$gameID,$pot){
    $query = "UPDATE `game` SET `g_win_pot`=$pot WHERE `g_id` = $gameID";
    $result = @mysqli_query($link,$query);
    if(mysqli_error($link)) handleError("query 8"); 
    
}
	
//=================================================================================
// MAIN
//=================================================================================
if (!gameOver($link,$g_id)){
	
	$round = getCurrentRound($link,$g_id);  
	$numPlayers = getNumPlayers($link,$g_id);   
	$numBets = getNumBetsForRound($link,$g_id,$round);
    $pot = getTotalPot($link,$g_id);
	
	if($round < 4){    		
	    if($numBets == $numPlayers){ //all bets for round are in			
            updateRound($link,$g_id);
            $round = getCurrentRound($link,$g_id);       
		} //end if
		$returnString = "myStatus=OK&theRound=" . $round . "&totalPot=" . $pot;
    }elseif($round == 4){  // else last betting round (4)
		if($numBets == $numPlayers){ //all bets for round are in and game is over	
			gameIsOver($link,$g_id);		
			updateGame($link,$g_id,$pot);
			$returnString = "myStatus=GAME_OVER&totalPot=" . $pot; 		
		}else{ //some bets, but not all
			$returnString = "myStatus=OK&theRound=" . $round . "&totalPot=" . $pot;
		} // end if-elseif-else
			
    }else{
        $returnString = "myStatus=ERROR_IN_ROUND";
    }//end if-elseif-else

}else{ // Game is over
  $pot = getTotalPot($link,$g_id);
  updateGame($link,$g_id,$pot);
  $returnString = "myStatus=GAME_OVER&totalPot=" . $pot;  
}// end if-else

$returnString .= "&server_data=" . getAllBets($link,$g_id);
print $returnString;
print "&dummy=dummy";
    
 
?>

	