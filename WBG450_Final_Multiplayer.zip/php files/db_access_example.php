<?php

require_once("settings.inc.php");

//Performing SQL query
$query = "SELECT * FROM `player`"; //this is the SQL query - notice the "backticks" around player
if($result = mysqli_query($link,$query)){
	
			//Print results in HTML
			print "<center><h1>My Player Table</h1><br />";
			print "<table border='1' cellpadding='2'>\n";
			while ($line = mysqli_fetch_assoc($result)) {   //calling a PHP mysqli function
					print "\t<tr>\n"; // new row
					foreach ($line as $col_value) {
						print "\t\t<td>$col_value</td>\n"; //each column (or field)
					}
					print "\t</tr>\n";
			}
			print "</table></center>\n";
}

//Free resultset
mysqli_free_result($result);

//Closing Connection
mysqli_close($link);
?>